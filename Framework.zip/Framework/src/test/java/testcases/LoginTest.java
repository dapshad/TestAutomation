package testcases;

import base.BaseClass;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;
import pages.LoginPage;

public class LoginTest extends BaseClass {

    WebDriver driver;
    @Test
    public void loginToApplication()
    {
        LoginPage page = new LoginPage(driver);
        page.loginToApplication("ineuron@ineuron.ai","ineuron");

    }
}
