package base;

import browserFactory.BrowserFactory;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;


public class BaseClass {

    public WebDriver driver;

  @BeforeClass
    public void setupBrowser()
    {
        System.out.println("Browser setup is ready");
       driver= BrowserFactory.startBrowser("Chrome", "https://ineuron-courses.vercel.app/login");
    }

    @AfterClass
    public void closeBrowser(){
      driver.quit();
    }
}
